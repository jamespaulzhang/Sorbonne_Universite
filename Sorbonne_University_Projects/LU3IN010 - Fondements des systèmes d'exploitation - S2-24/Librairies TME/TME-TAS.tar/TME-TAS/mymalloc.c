#include "affiche_tas.h"

char tas[TAILTAS  +1];
int libre;

/* A COMPLETER */

int main() {
  tas_init();
  afficher_tas();
}
