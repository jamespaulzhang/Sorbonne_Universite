const express = require ('express');

const app= express();

//app.use(express.static(path.join(__dirname, 'public')))

console.log('text');