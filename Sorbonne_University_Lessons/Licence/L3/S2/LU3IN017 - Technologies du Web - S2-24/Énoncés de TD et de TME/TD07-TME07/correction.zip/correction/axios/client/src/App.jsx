import { useState } from 'react';
import TestAxios from './testaxios';

function App() {
  

  return (
  	<TestAxios />
  )
}

export default App
