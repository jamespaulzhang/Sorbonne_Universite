const express = require('express');
const cors = require('cors');
const port = 8000;

const app=express();

app.use(cors({origin:"*"}));

app.use(express.json());

app.get('/', (req, res) =>{ 
	res.setHeader('Content-type', 'text/plain;charset=UTF-8');
	res.send('Message reçu');
})
.post('/', (req, res) =>{
	console.log("Requête POST reçue : "+req.body.texte);
	res.end();
})

app.listen(port);