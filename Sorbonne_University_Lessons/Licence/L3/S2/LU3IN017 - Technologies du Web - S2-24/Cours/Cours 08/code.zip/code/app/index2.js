const {MongoClient} = require('mongodb');

async function writeDB(client){
    //databasesList = await client.db().admin().listDatabases();
    
   const dbName="asso";

	const newMessage = {
		author_id: "158",
		author_name: "moi",
		date: " XXX ",
		text: "un 3e	1er texte"
	}

//	const insertMessage = await client.db(dbName).collection("messages").insertOne(newMessage);

	/*
	const options={ projection : { text: 1, date: 1} }
	const cursorListMessages  = await client.db("asso").collection("messages").find(query,options);
	const arrayListMessages = await cursorListMessages.toArray();
	console.log(arrayListMessages);*/
	
	
	const query = { author_id : {$in : ["158", "159"]} };
	const options={ projection : { text: 1} };
	async function getMessageID (idAuthor, text) {
		const query = {author_id : idAuthor, text: text};
		const options = {projection: {text: 1}}
	
		const cursorListMessages  = await client.db("asso").collection("messages").find(query,options);
		const arrayListMessages = await cursorListMessages.toArray();
	
		return (arrayListMessages[0]._id)
	}
	const cursorListMessages  = await client.db("asso").collection("messages").find(query,options);
 	const arrayListMessages = await cursorListMessages.toArray();
	console.log(arrayListMessages);
	/*const IDres = await getMessageID("158", "un 3e texte");
	console.log(IDres);*/
 
/*	const mess = await client.db(dbName).collection("messages").findOne( {_id: IDres} );
	console.log(mess);*/

}
 
async function main() {
	const url = "mongodb://localhost";
	const client = new MongoClient(url);
	 
	try {
        // Connect to the MongoDB cluster
        await client.connect();
 
        // Make the appropriate DB calls
        await writeDB(client);
 
    } catch (e) {
        console.error(e);
    } finally {
        await client.close();
    }
}

main().catch(console.error);
