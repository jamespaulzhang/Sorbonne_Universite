const {MongoClient} = require('mongodb');

async function writeDB(client){
    databasesList = await client.db().admin().listDatabases();
    
    const dbName="demoMongo";
 
    console.log("Databases:");
    databasesList.databases.forEach(db => console.log(` - ${db.name}`));
    
    const suppr = await client.db(dbName).collection("coll1").deleteMany(
		{
				a: {$gte: -100},
		}
    )
    
    const newCol = [{a:34}, {b:128}, {cle:"valeur"}, {a:42}, {a:18}
		];
    
    const result1 = await client.db(dbName).collection("coll1").insertOne({a:34});
    const result2 = await client.db(dbName).collection("coll1").insertMany(newCol);
    
    const result3 = await client.db(dbName).collection("coll1").findOne({c:1});
    if (result3) {
		console.log("Trouvé!");
	}
	else {
		console.error("y'a un os");
	}
	
	const cursor4 = await client.db(dbName).collection("coll1").find(
		{
			a: {$gte: 20}
		}
	)
	const result4 = await cursor4.toArray();
	
	console.log(result4.length);
    
};

async function main() {
	const url = "mongodb://localhost";
	const client = new MongoClient(url);
	 
	try {
        // Connect to the MongoDB cluster
        await client.connect();
 
        // Make the appropriate DB calls
        await writeDB(client);
 
    } catch (e) {
        console.error(e);
    } finally {
        await client.close();
    }
}

main().catch(console.error);

/* 

if (error) throw error;
	
	console.log("Connecté à la base de données "+dbName);
	
	const db = client.db(dbName);
	
	db.createCollection("col1", function (error, results) {
		if (error) throw error;
		
		console.log("Collection col1 créée");
	});
	
	db.collection("col1").insertOne({nom:"Dupont"}, function (error, r) {
			if (error) throw error;
		});
		
	db.collection("col1").insertMany([{nom:"Martin"}, {nom: "Durand"}], function (error, r) {
			if (error) throw error;
		});
*/


