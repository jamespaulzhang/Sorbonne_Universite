import * as THREE from "three";

function main() {
  const canvas = document.getElementById('canvas1');

	// La scène  
  const scene = new THREE.Scene();
  
  // Le moteur de rendu
  const renderer = new THREE.WebGLRenderer({antialias: true, canvas});

}

main();