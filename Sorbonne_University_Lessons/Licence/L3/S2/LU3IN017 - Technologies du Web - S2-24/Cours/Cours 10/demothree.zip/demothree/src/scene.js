import * as THREE from "three";

function main() {
  const canvas = document.getElementById('canvas1');

	// La scène  
  const scene = new THREE.Scene();
}

main();