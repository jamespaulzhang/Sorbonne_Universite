import * as THREE from "three";

function main() {
  const canvas = document.getElementById('canvas1');

	// La scène  
  const scene = new THREE.Scene();
  
  // Le moteur de rendu
  const renderer = new THREE.WebGLRenderer({antialias: true, canvas});
  
	// La caméra
  const fov = 60;
  const aspect = 2;  // Valeur par défaut
  const near = 0.1;
  const far = 5;  
  //const far = 1.5;
  const camera = new THREE.PerspectiveCamera(fov, aspect, near, far);

	renderer.render(scene, camera);

}

main();