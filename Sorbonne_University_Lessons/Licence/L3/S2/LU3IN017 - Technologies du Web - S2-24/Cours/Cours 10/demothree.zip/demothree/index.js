import './src/scene.js';
//import './src/moteur.js';
//import './src/camera.js';
//import './src/objets.js';
//import './src/lumiere.js';
//import './src/positions.js';
//import './src/demo.js';