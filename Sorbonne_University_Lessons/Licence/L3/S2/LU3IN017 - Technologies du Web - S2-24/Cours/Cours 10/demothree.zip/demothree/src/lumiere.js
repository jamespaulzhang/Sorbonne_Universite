import * as THREE from "three";

function main() {
  const canvas = document.getElementById('canvas1');

	// La scène  
  const scene = new THREE.Scene();
  
  // Le moteur de rendu
  const renderer = new THREE.WebGLRenderer({antialias: true, canvas});
  
	// La caméra
  const fov = 60;
  const aspect = 2;  // Valeur par défaut
  const near = 0.1;
  const far = 5;  
  //const far = 1.5;
  const camera = new THREE.PerspectiveCamera(fov, aspect, near, far);

	// Les objets  
  const boxWidth = 1;
  const boxHeight = 1;
  const boxDepth = 1;
  const geometry = new THREE.BoxGeometry(boxWidth, boxHeight, boxDepth);

  const material = new THREE.MeshPhongMaterial({color: 0x44aa88});  // greenish blue

  const cube = new THREE.Mesh(geometry, material);
  scene.add(cube);
  
  	// La source de lumière
  {
	const color = 0xFFFFFF;
	const intensity = 1;
	const light = new THREE.DirectionalLight(color, intensity);
	scene.add(light);
	}

	renderer.render(scene, camera);

}

main();