const express = require ('express');
const cors = require ('cors');

const router = express.Router();

const app = express();
const port = 8000;

app.use(cors());

router.use(express.urlencoded({extended: true}))
.use(express.json());

router.get('/', (req, res) => {
	res.setHeader('Content-Type', 'text/plain;charset=UTF-8');
	res.send("Serveur à l'écoute");	
})
.get('/user', (req, res) => {
	let new_user=JSON.stringify({nom: "Hugo", prenom: "Victor"});
	res.json(new_user);
})
.post('/adduser', (req, res) =>{
	console.log(req.body);
	res.json(JSON.stringify(req.body));
})
.use( (req, res, next) =>{
	res.setHeader('Content-Type', 'text/plain;charset=UTF-8');
	res.status(404).send("Cette page n'existe pas.");
});

app.use('/', router);

app.listen(port, function() {
	console.log('Le serveur écoute le port '+port);
});
