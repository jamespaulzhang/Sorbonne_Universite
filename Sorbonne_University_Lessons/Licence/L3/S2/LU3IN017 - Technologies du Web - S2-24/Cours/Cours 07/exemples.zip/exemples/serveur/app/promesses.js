promesse = (valeur) => {
	return new Promise( (succes, echec) =>{
		if (valeur<1)
			{succes("ça marche!")}
		else 
			{echec(new Error("Raté…"))}	
	});
}

const prom1 = promesse(0);
const prom2 = promesse(2);

prom1.then  ( () => {console.log("ok")} );
prom2.catch ( (e) => {console.log(e.message)} );

const prom3 = promesse(3);
prom3.then (
	() => { console.log("ouf!") }
)
.catch (
	(e) => { console.log(e.message) }
)