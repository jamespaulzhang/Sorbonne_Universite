const express = require ('express');
const path = require ('path');

const router = express.Router();

const app = express();
const port = 8000;

router.use(express.static(path.join(__dirname, 'public')))
.use(express.urlencoded({extended: true}))
.use(express.json());

router.get('/', (req, res) => {
	res.setHeader('Content-Type', 'text/plain;charset=UTF-8');
	res.send("Serveur à l'écoute");	
})
.get('/test_form.html', (req, res) =>{
	res.sendFile('test_form.html');
})
.post('/reponse', (req, res) =>{
	console.log(req.body);
	res.send(JSON.stringify(req.body));
	
	//res.end();
})
.use( (req, res, next) =>{
	res.setHeader('Content-Type', 'text/plain;charset=UTF-8');
	res.status(404).send("Cette page n'existe pas.");
});

app.use('/', router);

app.listen(port, function() {
	console.log('Le serveur écoute le port '+port);
});
