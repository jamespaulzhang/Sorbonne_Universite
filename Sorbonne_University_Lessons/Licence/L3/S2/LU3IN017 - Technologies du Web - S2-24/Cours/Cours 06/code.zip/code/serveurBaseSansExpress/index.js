const http = require("http");
const monServeur = http.createServer( (req, res) =>{
	// On peut accéder à req.headers, req.method, req.url
	
	// Envoi de l'entête
	res.writeHead(200,{"Content-Type": "text/plain"});
	// Envoi du contenu
	res.write('Hello World '+req.url);
	// Nécessaire pour indiquer au client que l'envoi est terminé, et qu'il n'y a plus rien à attendre
	res.end();
});
// Lancement du serveur sur le port 3000
monServeur.listen(3000);